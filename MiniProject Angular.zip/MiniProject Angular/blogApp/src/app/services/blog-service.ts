import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface BlogPost {
  title: string;
  slug: string;
  content: string;
  user_id: number;
  // tags[]: TagContentType;

  createdAt: string;
  updatedAt: string;
}
@Injectable({
  providedIn: 'root'
})
export class BlogService {
  private baseURL = 'http://localhost:3000/posts';

  constructor(private http: HttpClient) { }

  //GET All Blog post
  getBlogPost(): Observable<BlogPost[]> {
    console.log("in blog service")
    return this.http.get<BlogPost[]>(`${this.baseURL}/showAllPost`);
  }

  //POST new BlogPost
  addBlogPost(blp: BlogPost): Observable<any> {
    console.log("blog post service");
    return this.http.post(`${this.baseURL}/addPost`, blp);
  }

  //DELETE BlogPost
  deleteBlogPost(id: number): Observable<any> {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  //GETBYID BlogPost
  getBlogPostById(id: number): Observable<BlogPost> {
    return this.http.get<BlogPost>(`${this.baseURL}/${id}`);
  }

  //Get By userID
  getBlogPostByUserId(id: number): Observable<BlogPost> {
    const token = localStorage.getItem('angular18Token');
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get<BlogPost>(`${this.baseURL}/byUserId`, { headers })
  }
}
