import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
interface TokenPayload {
  user_id: number;
  email: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  getUserId(): number | null {
    const token = localStorage.getItem('angular18Token');
    if (!token) return null;

    try {
      const decoded = jwtDecode<any>(token);
      console.log('Decoded token:', decoded); // { id: 7, email: 'pawar@gmail.com', ... }
      console.log('User ID:', decoded.id);
      return decoded.id;
    } catch (err) {
      console.error('Invalid token', err);
      return null;
    }
  }
}


