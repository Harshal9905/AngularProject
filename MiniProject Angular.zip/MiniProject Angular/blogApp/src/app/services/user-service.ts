import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface BlogUser {
  username: string;
  email: string;
  // profilePicture: string;
  // bio: string;
  createdAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseURL = 'http://localhost:3000/user';

  constructor(private http: HttpClient) {

  }

  //GET All Users
  getAllUsers() {
    console.log("Fetch Data succesfully");
    return this.http.get<BlogUser[]>(`this.baseURL/register`);
  }

  //POST new User
  addUser(blu: BlogUser): Observable<any> {
    console.log("Registerd Succesfully");
    return this.http.post(`${this.baseURL}/register`, blu);
  }

  //DELETE User
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  //GET User By Id
  getUserById(id: number): Observable<BlogUser> {
    return this.http.get<BlogUser>(`${this.baseURL}/${id}`);
  }

}
