import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './components/user-component/user-component';

import { UserLogin } from './components/user-login/user-login';
import { Dashboard } from './components/dashboard/dashboard';
import { Home } from './components/home/home';
import { authGuard } from './guards/auth-guard';
import { BlogComponent } from './components/blog-component/blog-component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'register', component: UserComponent },
  { path: 'login', component: UserLogin },
  {path:'addPost', component: BlogComponent},
  {
    path: 'dashboard', component: Dashboard, canActivate: [authGuard]
  },
  { path: 'home', component: Home }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
