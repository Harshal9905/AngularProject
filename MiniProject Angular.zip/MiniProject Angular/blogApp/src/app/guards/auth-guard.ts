import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('angular18Token');

  if (token) {
    return true; // user is logged in
  } else {
    router.navigate(['/login']); // redirect to login
    return false; // block access
  }
};
