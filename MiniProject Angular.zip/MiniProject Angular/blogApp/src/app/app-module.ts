import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';

import { BlogComponent } from './components/blog-component/blog-component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from './components/user-component/user-component';
import { UserService } from './services/user-service';
import { HttpClientModule, provideHttpClient } from '@angular/common/http';
import { UserList } from './components/user-list/user-list';

import { UserLogin } from './components/user-login/user-login';
import { Dashboard } from './components/dashboard/dashboard';
import { Navbar } from './components/navbar/navbar';
import { Home } from './components/home/home';



@NgModule({
  declarations: [
    App,
    UserComponent,
    BlogComponent,
    UserList,

    UserLogin,
    Dashboard,
    Navbar,
    Home,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideHttpClient()
  ],
  bootstrap: [App]
})
export class AppModule { }
