import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: false,
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {
  username: string | null = localStorage.getItem('username'); // add this property

  constructor(private router: Router) { }

  logout() {
    console.log("logout");
    localStorage.removeItem('angular18Token');
    localStorage.removeItem('username');
    this.router.navigate(['/login']);
  }
}
