import { Component, NgZone } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BlogPost, BlogService } from '../../services/blog-service';

@Component({
  selector: 'app-blog-component',
  standalone: false,
  templateUrl: './blog-component.html',
  styleUrl: './blog-component.css',
})
export class BlogComponent {

  submitted = false;

  postForm!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private blogService: BlogService
  ) { }
  ngOnInit(): void {
    this.postForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(100)]],
      content: ['', [Validators.required]],
      // Optional: you can add tags
      // tags: ['']
    });
  }

  onSubmit() {
    this.submitted = true;
    if (!this.postForm.invalid) {

      return false;
    } else {
      const post: BlogPost = {
        title: this.postForm.value.title,
        content: this.postForm.value.content,
        user_id: localStorage.getItem('userId') || '1', // example
        slug: this.postForm.value.title.toLowerCase().replace(/\s+/g, '-'),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      return this.blogService.addBlogPost(post).subscribe({
        complete: () => {
          console.log('Post successfully created!'),
            this.ngZone.run(() => this.router.navigateByUrl('/home'));
        }, error: (e) => {
          console.log(e);
        },
      });
    }




  }
}
