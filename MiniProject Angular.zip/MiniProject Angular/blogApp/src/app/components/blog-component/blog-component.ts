import { Component, NgZone } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BlogPost, BlogService } from '../../services/blog-service';
import { AuthService } from '../../services/auth-service';

@Component({
  selector: 'app-blog-component',
  standalone: false,
  templateUrl: './blog-component.html',
  styleUrl: './blog-component.css',
})
export class BlogComponent {

  submitted = false;

  postForm!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private blogService: BlogService,
    private authService: AuthService
  ) { }
  ngOnInit(): void {
    this.postForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(100)]],
      content: ['', [Validators.required]],
      // Optional: you can add tags
      // tags: ['']
    });
  }

  onSubmit() {
    this.submitted = true;
    
    if (this.postForm.invalid) {

      return false;
    } else {

      const post: BlogPost = {
        title: this.postForm.value.title,
        content: this.postForm.value.content,
        user_id: Number(this.authService.getUserId()), // convert to string, use empty string if null
        slug: this.postForm.value.title.toLowerCase().replace(/\s+/g, '-'),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      if (post.user_id == 0) {
        alert("PLease Login to Add Blog");
        this.router.navigateByUrl('login');
        return false;
      }
      return this.blogService.addBlogPost(post).subscribe({

        complete: () => {
          alert("Blog Added successfully. ")
          console.log('Post successfully created!'),
            this.ngZone.run(() => this.router.navigateByUrl('/home'));
        }, error: (e) => {
          console.log(e);
        },
      });
    }




  }
}
