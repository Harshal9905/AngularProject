import { Component } from '@angular/core';
import { BlogService } from '../../services/blog-service';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  posts: any[] = [];

  constructor(private blogService: BlogService) { }

  ngOnInit(): void {
    console.log("In home component")
    this.blogService.getBlogPost().subscribe({
      next: (data: any) => this.posts = data,
      error: (err) => console.error(err)
    });
  }
}
