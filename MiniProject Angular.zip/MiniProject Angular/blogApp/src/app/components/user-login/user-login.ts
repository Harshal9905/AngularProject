import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-login',
  standalone: false,
  templateUrl: './user-login.html',
  styleUrl: './user-login.css',
})
export class UserLogin {
  logiObj: any = {
    "EmailId": "",
    "Password": ""
  };

  // inject HttpClient and Router in constructor
  constructor(private http: HttpClient, private router: Router) { }
  onLogin() {
    this.http.post("http://localhost:3000/user/login", this.logiObj).subscribe((res: any) => {
      if (res.result) {
        alert("Login Success");
        // Save token in localStorage (optional)
        localStorage.setItem('username', res.data.user.username);
        localStorage.setItem('angular18Token', res.data.token);
        // Navigate to dashboard
        this.router.navigateByUrl('dashboard')
      } else {
        console.log("this is login");
        alert(res.message)
      }
    })
  }
}
