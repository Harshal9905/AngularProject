// routes/posts.js


const express = require('express');
const router = express.Router();
const mysqlConnection = require('../lib/db');



// Get all posts with author names
router.get('/showAllPost', (req, res) => {
    console.log("In Backend");
    const sql = `
       SELECT blogs.blog_id, blogs.title, blogs.content, blogs.created_at, users.username 
        FROM blogs 
        JOIN users ON blogs.user_id = users.user_id
        ORDER BY blogs.created_at DESC
    `;
    mysqlConnection.query(sql, (err, results) => {
        console.log("In Backend 2");
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Database error' });
        }
        res.json(results);
    });
});

router.post('/addPost', async (req, res) => {
    const { title, content, user_id, createdAt, updatedAt } = req.body;

    if (!title || !content || !user_id) {
        return res.status(400).json({ message: 'All fields are required ' });
    }

    try {
        const sql = `INSERT INTO blogs (user_id, title, content) Values (?, ?, ?)`;
        mysqlConnection.query(sql, [user_id, title, content], (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ message: 'Failed to add post', details: err.sqlMessage });
            }
            res.status(201).json({
                message: 'Post added successfully',

            })
        });

    } catch (err) {
        console.error(err);
        res.status(500).join({ message: 'Server error' })
    }
});

module.exports = router;
