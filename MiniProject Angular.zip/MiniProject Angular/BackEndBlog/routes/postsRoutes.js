// routes/posts.js


const express = require('express');
const router = express.Router();
const mysqlConnection = require('../lib/db');

// Get all posts with author names
router.get('/showAllPost', (req, res) => {
    console.log("In Backend");
    const sql = `
       SELECT blogs.blog_id, blogs.title, blogs.content, blogs.created_at, users.username 
        FROM blogs 
        JOIN users ON blogs.user_id = users.user_id
        ORDER BY blogs.created_at DESC
    `;
    mysqlConnection.query(sql, (err, results) => {
        console.log("In Backend 2");
        if (err) {
            console.error(err);
            return res.status(500).json({ message: 'Database error' });
        }
        res.json(results);
    });
});

module.exports = router;
