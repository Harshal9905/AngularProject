

const express = require('express');
const router = express.Router();
const mysqlConnection = require('../lib/db');
const bcrypt = require('bcryptjs');  // For hashing passwords
const jwt = require('jsonwebtoken'); // For generating auth tokens

// Secret key for JWT (keep this private, ideally in .env)
const JWT_SECRET = 'your_secret_key_here';

// 🟢 GET all users (for testing, optional)
router.get('/', (req, res) => {
    mysqlConnection.query('SELECT * FROM users', (err, rows) => {
        if (!err) {
            res.json(rows);
        } else {
            console.log(err);
            res.status(500).send('Database query failed');
        }
    });
});

// 🟢 REGISTER USER
router.post('/register', async (req, res) => {
    const { userName, email, password } = req.body;

    if (!userName || !email || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(password, salt);

        // Insert user into DB
        const sql = `INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)`;
        mysqlConnection.query(sql, [userName, email, password_hash], (err, result) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ message: 'Failed to add user', details: err.sqlMessage });
            }

            res.status(201).json({
                message: 'User registered successfully',
                userId: result.insertId,
                user: { username: userName, email }
            });
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
});

// 🟢 LOGIN USER
router.post('/login', (req, res) => {
    const { EmailId, Password } = req.body;

    if (!EmailId || !Password) {
        return res.status(400).json({ result: false, message: 'Email and Password are required' });
    }

    const sql = `SELECT * FROM users WHERE email = ?`;
    mysqlConnection.query(sql, [EmailId], async (err, results) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ result: false, message: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(401).json({ result: false, message: 'Invalid email or password' });
        }

        const user = results[0];

        // Compare password
        const isMatch = await bcrypt.compare(Password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ result: false, message: 'Invalid email or password' });
        }

        // Generate JWT token
        const token = jwt.sign(
            { id: user.user_id, email: user.email },
            JWT_SECRET,
            { expiresIn: '2h' }
        );

        res.json({
            result: true,
            message: 'Login successful',
            data: {
                token,
                user: { id: user.id, username: user.username, email: user.email }
            }
        });
    });
});

module.exports = router;
