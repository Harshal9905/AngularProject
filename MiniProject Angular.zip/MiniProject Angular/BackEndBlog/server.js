const express = require('express');
const cors = require('cors');
const bodyparser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const postsRoutes = require('./routes/postsRoutes');
const app = express();

// Enable CORS for Angular frontend
app.use(cors({ origin: 'http://localhost:4200' }));

// Parse JSON bodies
app.use(bodyparser.json());

// Routes
app.use('/user', userRoutes);
app.use('/posts', postsRoutes);


app.listen(3000, () => console.log('Express server started at 3000'));